EATER_CSV_UPLOAD_URL = "http://eater:8080/csv"
DICE_CSV_UPLOAD_URL = "http://dice:8080/upload"
DELIMITER = ";"
COOPER_URL = "cooper:6565"
